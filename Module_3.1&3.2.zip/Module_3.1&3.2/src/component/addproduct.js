import React, { Component } from 'react';

class Addproduct extends Component {
    constructor() {
        super();
        this.state = {
            data: {}
        }
    }

    getAllProduct() {
        this.setState({
            data:
            {
                custId: this.refs.custId.value,
                custName: this.refs.custName.value,
                custMobile: this.refs.custMobile.value,
                addr:this.refs.addr.value,
                description:this.refs.description.value,
                date:this.refs.date.value
            }
        }, function () {
            this.props.getData(this.state.data);
        }
        )
        this.refs.custId.value = "";
        this.refs.custName.value = "";
        this.refs.custMobile.value = "";
        this.refs.addr.value="";
        this.refs.description.value="";
        this.refs.date.value="";
    }

    render() {
        return (
            <div>
                <div>
                    <h2>Customer Registration Form</h2>
                    <div class="container-fluid">
                    <table border="1">
                        <tbody><tr>
                            <td>UserName  </td><td><input type="text" ref="custId" /></td></tr>
                            <tr><td>Email-Id  </td><td><input type="text" ref="custName" /></td></tr>
                            <tr><td>Mobile number </td><td><input type="text" ref="custMobile" /></td></tr>
                            <tr><td>Address  </td><td><input type="text" ref="addr" /></td></tr>
                            <tr><td>Description/Purpose Of Visit </td><td><input type="text" ref="description" /></td></tr>
                            <tr><td>Date oF Visit </td><td><input type="text" ref="date" /></td></tr>
                            <tr><td align="center" colspan="2"><button onClick={this.getAllProduct.bind(this)} >Log In</button></td>
                            </tr>
                        </tbody>
                    </table>
                    </div>
                </div>
                </div>
        );
    }
}
export default Addproduct;