import React, { Component } from 'react';

class ShowProduct extends Component {
    constructor() {
        super();
        this.state = {
            data: {}
        }
    }

    delete(id) {
        this.setState({
            abc: this.props.pobject.splice(id, 1)
        });
    }


    render() {
        const myListData = (<div>
            {this.props.pobject.map((data, key) =>
                <p key={data.custId} >
                Name : {data.custId}
                <br/>
                Email ID : {data.custName}
                <br/>
                Mobile Number : {data.custMobile}
                <br/>
                Address : {data.addr}
                <br/>
                Description : {data.description}
                <br />
                Date : {data.date}
                <br/>
                    {<button onClick={this.delete.bind(this, key)}>
                        Delete
    </button>}  </p>
            )}</div>);

        return (
            <div>
                <h2>Show All Product</h2>
                {myListData}
                </div>
        );
    }
}
    export default ShowProduct;