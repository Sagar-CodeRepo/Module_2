var fs = require("fs");
var express = require("express");
var appBody = require("body-parser");
var app = express();
app.use(appBody.json());


app.get("/getAllMobile", function (req, res) {
    console.log("---------Read the data from mobile json file-----");
    fs.readFile("mobile.json", "utf-8", function (readerr, readdata) {
        if (readerr) {
            console.log("Error in reading");
            res.send("Error in reading");
            res.end();
        }
        else {
            console.log("Data from file is" + readdata);
            res.send(readdata);
            res.end();
        }

    });
});


console.log("-------------find --------------");
app.get('/find', function (req, res) {
   
    fs.readFile("mobile.json", "utf-8", function (readerr, readdata) {
        if (readerr) {
            console.log("err in reading");
        }
        else {
            var allData = [];
            allData = JSON.parse(readdata);
            for (let i in allData) {
                if (allData[i].mobPrice > 10000 && allData[i].mobPrice < 50000) {
                    console.log(allData[i]);
                }
            }
            
        }
    });
});


console.log("------Update data in json file-------");
app.put("/update", function (req, res) {
    var mobdata = {
        "mobId": req.body.mobId,
        "mobName": req.body.mobName,
        "mobPrice": req.body.mobPrice,

    };
    console.log("Updated Mobile Id "+mobdata.mobId);
    fs.readFile("mobile.json", "utf-8", function (readerr, readdata) {
        if (readerr) {
            console.log("err in reading");
        }
        else {
            var allData = [];
            allData = JSON.parse(readdata);
            allData.forEach(element => {
                if(element.mobId==mobdata.mobId){
                    element.mobName=mobdata.mobName;
                    element.mobPrice=mobdata.mobPrice;
                }
               
            });
            
           
            data_json = JSON.stringify(allData);
            fs.writeFile("mobile.json", data_json, function (writeerr) {
                if (writeerr) {
                    console.log("err in write");
                }
                else {
                    console.log(data_json);
                }
            })
        }
    });
});


console.log("------Insert data in json file-------");
app.post("/addMobile", function (req, res) {
    var mobdata = {
        "mobId": req.body.mobId,
        "mobName": req.body.mobName,
        "mobPrice": req.body.mobPrice,
        
    };
    console.log("Mobile data after adding new mobile : "+mobdata.mobId);
    fs.readFile("mobile.json","utf-8",function(readerr,readdata){
        if(readerr){
            console.log("err in reading");
        }
        else{
            var allData=[];
            allData=JSON.parse(readdata);
            allData.push(mobdata);
            data_json=JSON.stringify(allData);
            fs.writeFile("emp.json",data_json,function(writeerr){
                if(writeerr)
                {
                    console.log("err in write");
                }
                else{
                    console.log(data_json);
                }
            })
        }
    });


});

console.log("-------------Delete--------------");
app.delete("/deleteMob/:id",function(req,res){
    var mobid=req.params.id;
    console.log("delte the items : "+mobid);
    fs.readFile("mobile.json","utf-8",function(readerr,readdata){
        if(readerr){
            console.log("err in reading");
        }
        else{
            var allData=[];
            allData=JSON.parse(readdata);
          for(let i in allData){
            if(allData[i].mobId==mobid){
                allData.splice(i,1);
            }
          }
            data_json=JSON.stringify(allData);
            fs.writeFile("mobile.json",data_json,function(writeerr){
                if(writeerr)
                {
                    console.log("err in write");
                }
                else{
                    console.log("data written");
                }
            })
        }
    });
});

console.log("--------------------------------------");
app.listen(3456, function (servererr, serverres) {
    if (servererr) {
        console.log("error in starting the server");
    }
    else {
        console.log("server staeted a 3456")
    }
})