import { Component, OnInit } from "@angular/core";
import { Mobile } from '../mobile';
import {MobileService} from './mobileservice';

@Component({
    selector: 'mob-app',
    templateUrl: './app.mobile.html',
    providers: [MobileService]
})

export class MobileComponent implements OnInit{
    mobile:Mobile[];
    constructor(private _mobileservice:MobileService)
    {
    
    }
    
    ngOnInit()
    {
    this._mobileservice.getAllProduct().subscribe((data:Mobile[])=>this.mobile=data);
    }
    delete(i:number):any{
        return this.mobile.splice(i,1);
    }
    
    sortId():any{this.mobile.sort(function abc(a,b)
        {
            return a.mobId-b.mobId;
        }
        );
    }
    
        sortName():any{
            this.mobile.sort(function abc(a,b){
                if(a.mobName.toLowerCase() > b.mobName.toLowerCase()){
                    return 1;
                }
             if(a.mobName.toLowerCase() < b.mobName.toLowerCase()){
                    return -1;
                }
                return 0;
            });
        }
    
        sortPrice():any{this.mobile.sort(function abc(a,b)
            {
                return a.mobPrice-b.mobPrice;
            }
            );
        }
    
    }