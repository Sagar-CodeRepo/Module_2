import { Injectable } from "@angular/core";
import { Mobile } from "../mobile";
import { HttpClient } from '@angular/common/http'

@Injectable()
export class MobileService {
    constructor(private http:HttpClient){}

    getAllProduct():any{
      return  this.http.get("assets/mobile.json");
    }
    
    mobileData:Mobile[] = [];


    delete(searchId) : Mobile[] {

        let mobTemp:Mobile[] = [];
        let i =0;
        for(let data of this.mobileData) {
            if(data.mobId == searchId)
            {
                this.mobileData.splice(i,1);
            }
            i++;
        }
        return this.mobileData;
    }
    
}