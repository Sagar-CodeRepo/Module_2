export class Mobile {
    mobId:number;
    mobName:string;
    mobPrice:number;
}